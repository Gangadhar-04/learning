#include<studio.h>
#include<conio.h>
void swap(int a,int b);
void main()
{
    int m=22,n=44;
    clrscr();
    printf("values before swap m=%d\n & n=%d",m,n);
    swap(m,n);
}
void swap(int a,int b)
{
    int temp;
    temp=a;
    a=b;
    b=temp;
    printf("\n values after swap m=%d\n &n=%d",a,b);
    getch();
}