const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));
app.use("/songs", express.static("songs"));

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/musicapp");

// User schema
const User = mongoose.model("User", {
  email: String,
  password: String
});

// Register API
app.post("/register", async (req, res) => {
  const user = new User(req.body);
  await user.save();
  res.send("Registered Successfully");
});

// Login API
app.post("/login", async (req, res) => {
  const user = await User.findOne(req.body);

  if (user)
    res.send("Login Success");
  else
    res.send("Invalid Email or Password");
});

app.listen(3000, () => console.log("Server running"));
