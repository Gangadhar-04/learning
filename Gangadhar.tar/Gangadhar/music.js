//  SELECT ELEMENTS
const playBtn = document.querySelector(".play img");
const prevBtn = document.querySelector(".controls button:nth-child(2)");
const nextBtn = document.querySelector(".controls button:nth-child(4)");

const progressBar = document.querySelector(".progress-bar input");
const currentTimeEl = document.querySelector(".progress-bar span:first-child");
const durationEl = document.querySelector(".progress-bar span:last-child");

const songTitle = document.querySelector(".song-info h4");
const artistName = document.querySelector(".song-info p");
const songCover = document.querySelector(".song-cover");

const volumeSlider = document.querySelector(".player-right input");

// AUDIO OBJECT 
const audio = new Audio();

//  SONG LIST 
const songs = [
  {
    title: "Song One",
    artist: "Artist One",
    src: "song1.mp3",
    cover: "images/song1.jpg"
  },
  {
    title: "Song Two",
    artist: "Artist Two",
    src: "song2.mp3",
    cover: "images/song2.jpg"
  },
  {
    title: "Song Three",
    artist: "Artist Three",
    src: "song3.mp3",
    cover: "images/song3.jpg"
  }
];

let songIndex = 0;
let isPlaying = false;

//  LOAD SONG
function loadSong(song) {
  songTitle.textContent = song.title;
  artistName.textContent = song.artist;
  songCover.src = song.cover;
  audio.src = song.src;
}

loadSong(songs[songIndex]);

//  PLAY / PAUSE 
function playSong() {
  isPlaying = true;
  audio.play();
  playBtn.src = "images/pause.png";
}

function pauseSong() {
  isPlaying = false;
  audio.pause();
  playBtn.src = "images/play.png";
}

playBtn.parentElement.addEventListener("click", () => {
  isPlaying ? pauseSong() : playSong();
});

//Next Song 
nextBtn.addEventListener("click", () => {
  songIndex++;
  if (songIndex >= songs.length) songIndex = 0;
  loadSong(songs[songIndex]);
  playSong();
});

// PREVIOUS SONG 
prevBtn.addEventListener("click", () => {
  songIndex--;
  if (songIndex < 0) songIndex = songs.length - 1;
  loadSong(songs[songIndex]);
  playSong();
});

//  UPDATE PROGRESS 
audio.addEventListener("timeupdate", () => {
  const progressPercent = (audio.currentTime / audio.duration) * 100;
  progressBar.value = progressPercent || 0;

  // Current time
  let currentMin = Math.floor(audio.currentTime / 60);
  let currentSec = Math.floor(audio.currentTime % 60);
  if (currentSec < 10) currentSec = "0" + currentSec;
  currentTimeEl.textContent = `${currentMin}:${currentSec}`;

  // Duration
  let durationMin = Math.floor(audio.duration / 60);
  let durationSec = Math.floor(audio.duration % 60);
  if (durationSec < 10) durationSec = "0" + durationSec;
  if (!isNaN(durationMin)) {
    durationEl.textContent = `${durationMin}:${durationSec}`;
  }
});

//  SEEK SONG 
progressBar.addEventListener("input", () => {
  const seekTime = (progressBar.value / 100) * audio.duration;
  audio.currentTime = seekTime;
});

//  AUTO NEXT 
audio.addEventListener("ended", () => {
  nextBtn.click();
});

//  VOLUME CONTROL 
volumeSlider.addEventListener("input", () => {
  audio.volume = volumeSlider.value / 100;
});
